# Free Game SFX Sampler — 20 Sounds

**Tagline:** A free taste of all seven Setrov Studio packs: UI, retro, sci-fi, ambience, foley, impacts and music.

**Price:** $0 — Pay What You Want, minimum $0 (suggested $2)  
**Kind of project:** Assets · **Classification:** Sound effects / Music · **Generative AI disclosure:** No (code-synthesized; itch says self-contained algorithms "don't require an AI disclosure" — answer "No" in the form so the page gets the *No AI* tag)

**Tags:** sound-effects, free, 8-bit, ui, sci-fi, music, royalty-free, no-ai

## Description
A free taste of all seven Setrov Studio packs: UI, retro, sci-fi, ambience, foley, impacts and music.

What you get:
- 20 sounds as WAV (44.1 kHz, 16-bit, mono), peak-normalized to -3 dBFS, no clipping, clean silent tails
- Clear, consistent file names (e.g. `ui_click_01.wav`) so you can drop them straight into Unity, Godot, GameMaker or any web engine
- Royalty-free for commercial games. No attribution required. See license.txt

Every sound was designed and synthesized from scratch in code (oscillators, filtered noise, envelopes). There are no recorded samples, no third-party libraries and no AI audio.

Try the Free Sampler first, or grab the full packs: UI Essentials, Retro 8-Bit Arcade, Sci-Fi Interface & Weapons, Seamless Ambience Loops, Synth Footsteps & Foley, Impacts & Explosions, Chiptune Music Loops.

## Upload checklist (Owner, manual)
- Cover: `marketing/free_sampler/cover_630x500.png` · Screenshots: `screenshot_1_waveforms.png`, `screenshot_2_spectrogram.png`, `screenshot_3_filelist.png`
- Preview audio: `marketing/free_sampler/free_sampler_preview.mp3` (embed as a downloadable demo or a SoundCloud-free audio upload marked "preview")
- Download file: `dist/free_sampler.zip`
- QA: 20 / 20 PASS. Integrated LUFS range for files ≥0.4s: -20.6 … -13.4
